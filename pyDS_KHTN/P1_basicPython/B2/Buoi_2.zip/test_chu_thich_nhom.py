chu_thich = '''Chú thích nhóm
Có thể viết bất kỳ cái gì trong đây
        *
    *       *

                    abc
'''

print(chu_thich)


