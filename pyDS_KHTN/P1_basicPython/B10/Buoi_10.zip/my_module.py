def tinh_diem_tb(hk1, hk2):
    return (hk1 + hk2 * 2) / 3

def tinh_bmi(can_nang, chieu_cao):
    return can_nang / chieu_cao ** 2

tong = lambda a, b: a + b

hieu = lambda a, b: a - b

loi_chao = "Chào mừng đến với Python"

def tinh_tong():
    return 4 + 5 + 6