def func_module_cha_1():
    print("Đây là hàm trong module cha 1")

def func_module_cha_2():
    print("Đây là hàm trong module cha 2")

def func_module_cha_3():
    print("Đây là hàm trong module cha 3")