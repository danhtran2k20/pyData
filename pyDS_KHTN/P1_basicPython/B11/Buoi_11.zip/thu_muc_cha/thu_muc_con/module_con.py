def func_module_con_1():
    print("Đây là hàm trong module con 1")

def func_module_con_2():
    print("Đây là hàm trong module con 2")

def func_module_con_3():
    print("Đây là hàm trong module con 3")