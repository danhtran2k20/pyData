print("Chào các bạn")

print(10)

print("Hello mọi người")